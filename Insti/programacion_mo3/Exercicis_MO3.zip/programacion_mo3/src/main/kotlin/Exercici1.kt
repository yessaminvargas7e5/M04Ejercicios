import java.util.*
/*
fun main() {
    val num1 = 20
    if(num1 > 18){
        println("Ets major d'edat")
    } else
}
//Si no = else
 */