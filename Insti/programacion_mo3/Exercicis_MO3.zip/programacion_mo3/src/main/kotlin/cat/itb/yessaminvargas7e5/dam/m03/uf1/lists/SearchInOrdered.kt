package cat.itb.yessaminvargas7e5.dam.m03.uf1.lists

import java.util.*

/*fun main() {
    val scanner = Scanner(System.`in`)
    val numberOrden = scanner.nextInt()
    val numberList = List(size){scanner.nextInt()}
    val toFind = scanner.nextInt()
    var found = false
    for (value in numberList)
        if (value==toFind)
            found==true
}

 */



//val numeroList = list(size) {scaner}
//val toFined  = scanner
//val found = salse
//for vlue in list
// if (value ==toafinf)
// found== true