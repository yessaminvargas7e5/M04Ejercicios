package cat.itb.yessaminvargas7e5.dam.m03.uf1.seleccio

/*import java.util.*

fun main() {
    val scanner = Scanner(System.`in`).useLocale(Locale.UK)
    val habitatge = scanner.next()
    val aigua = scanner .nextInt()
    val habitatgeLetra = when (habitatge){
        "a"-> 2.5
        "b"-> 6.50
        "c"-> 7.36
        "d"-> 11.39
        "e"-> 12.29
        "f"-> 17.55
        "g"-> 28.45
        "h"-> 41.14
        "i"-> 62.27
        else-> println("error")
    }
    val consuMen = when(aigua){
     in 0..6
     in



    }

}
Corrigelo como lo hizo el profe que lo tuyo era muy largo
 */