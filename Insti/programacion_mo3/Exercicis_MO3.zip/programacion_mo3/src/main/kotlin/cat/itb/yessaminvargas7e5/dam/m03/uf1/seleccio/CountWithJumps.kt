package cat.itb.yessaminvargas7e5.dam.m03.uf1.seleccio

import java.util.*

fun main() {
    val scanner = Scanner(System.`in`)
    val numEnter = scanner.nextInt()
    val salts = scanner.nextInt()
    for (i in 1..10 step salts) println(i)
}