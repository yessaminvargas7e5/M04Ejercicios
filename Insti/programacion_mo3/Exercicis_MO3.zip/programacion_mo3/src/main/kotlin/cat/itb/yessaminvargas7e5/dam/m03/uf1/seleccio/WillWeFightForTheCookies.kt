package cat.itb.yessaminvargas7e5.dam.m03.uf1.seleccio

import java.util.*
/*fun main() {
    val scanner = Scanner(System.`in`)
    val NumPersones = scanner.nextInt()
    val NumGaletes = scanner.nextInt()
    if (NumPersones == NumGaletes) {
        println("Let's Eat")
    } else
        println("Let's Fight")
}


fun main() {
    val scanner = Scanner(System.`in`)
    val NumPersones = scanner .nextInt()
    val NumGaletes = scanner .nextInt()
    if (NumPersones % NumGaletes == 0){
        println("Let's Eat")
    }
    else
        println("Let's Fight")
}


 */