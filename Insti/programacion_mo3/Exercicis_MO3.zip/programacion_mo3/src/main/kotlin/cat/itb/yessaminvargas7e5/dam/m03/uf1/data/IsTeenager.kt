import java.util.*

fun main() {
    val scanner = Scanner(System.`in`)
    val edat = scanner .nextInt()
    val entre = edat in 10..20
    println(entre)
}