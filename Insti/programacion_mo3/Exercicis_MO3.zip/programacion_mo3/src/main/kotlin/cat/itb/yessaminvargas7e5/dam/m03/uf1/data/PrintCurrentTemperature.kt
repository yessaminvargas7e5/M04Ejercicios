fun main() {
    var temperature = 45.2
    println(temperature)
    temperature += 1
    println(temperature)
}