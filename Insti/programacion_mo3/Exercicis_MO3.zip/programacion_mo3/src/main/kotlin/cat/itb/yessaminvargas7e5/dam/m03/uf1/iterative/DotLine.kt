package cat.itb.yessaminvargas7e5.dam.m03.uf1.iterative


import java.util.*

fun main(){
    val scanner = Scanner(System.`in`)
    val dotAmmount = scanner.nextInt()
    for(i in 0 until dotAmmount){
        println(".")
    }
}
