import java.util.*

fun main() {
    val scanner = Scanner(System.`in`)
    val a = scanner .nextInt()
    val b = scanner .nextInt()
    val sum = a + b
    println(sum)

}