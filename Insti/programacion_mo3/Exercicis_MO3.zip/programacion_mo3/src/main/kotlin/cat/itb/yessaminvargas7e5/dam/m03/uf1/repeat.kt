package cat.itb.yessaminvargas7e5.dam.m03.uf1

fun main() {
    repeat(10) {
        println(1)
    }
}