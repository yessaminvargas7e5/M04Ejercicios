import java.util.*

fun main() {
    val scanner = Scanner(System.`in`)
    val number1 = scanner .nextInt()
    val doble = number1 * 2
    println(doble)
}