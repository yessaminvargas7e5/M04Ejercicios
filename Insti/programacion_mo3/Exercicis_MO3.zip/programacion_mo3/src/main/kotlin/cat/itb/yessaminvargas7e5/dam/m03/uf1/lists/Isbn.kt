package cat.itb.yessaminvargas7e5.dam.m03.uf1.lists

/*import java.util.*

fun main() {
    val scanner = Scanner(System.`in`)
    val codigoGrupa = MutableList(1){scanner.nextInt()}
    val codiEditor = MutableList(4){}
    val caracterControl = scanner.nextInt()







    println(numberList)
}

 */
