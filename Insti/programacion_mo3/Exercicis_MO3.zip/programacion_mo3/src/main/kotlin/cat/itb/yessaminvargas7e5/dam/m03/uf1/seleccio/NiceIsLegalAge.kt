package cat.itb.yessaminvargas7e5.dam.m03.uf1.seleccio

import java.util.*

fun main() {
    val scanner = Scanner(System.`in`)
    val EdatUsuari = scanner.nextInt()
    if (EdatUsuari >= 18) {
        println("Ets major d'edat")
    }
    else
        println("No ets major d'edat")

}
