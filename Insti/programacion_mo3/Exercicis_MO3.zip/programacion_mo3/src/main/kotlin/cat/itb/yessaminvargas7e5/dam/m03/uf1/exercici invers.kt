package cat.itb.yessaminvargas7e5.dam.m03.uf1

fun main() {
   for ( i in 2 downTo 1) {
        println(i)
    }
    for (i in 3 downTo 1){
        println(i)
    }

    for (i in 20 downTo 1) {
        println(i)
    }
}