package cat.itb.yessaminvargas7e5.dam.m03.uf1.introfunctions

fun main() {
    val value = "55"
    val currency = "dollars"
    val price = "$value $currency" // "55 dollars"
}