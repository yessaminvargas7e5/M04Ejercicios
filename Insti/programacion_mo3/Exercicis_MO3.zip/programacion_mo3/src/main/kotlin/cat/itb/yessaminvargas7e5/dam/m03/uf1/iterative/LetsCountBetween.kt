package cat.itb.yessaminvargas7e5.dam.m03.uf1.iterative

import java.util.*

fun main() {
    val scanner = Scanner(System.`in`)
    val minim = scanner.nextInt()
    val maxim = scanner.nextInt()
    for (i in minim until maxim) println(i)



}

