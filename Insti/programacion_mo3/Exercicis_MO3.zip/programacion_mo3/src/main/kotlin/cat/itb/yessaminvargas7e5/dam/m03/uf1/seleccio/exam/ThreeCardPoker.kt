import java.util.*

fun main() {
    val scanner = Scanner(System.`in`)
    val cartaInicial = scanner.nextInt()
    //val cartaMedi = scanner.next

}

