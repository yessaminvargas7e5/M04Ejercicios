
rootProject.name = "Exercicis_MO3"

